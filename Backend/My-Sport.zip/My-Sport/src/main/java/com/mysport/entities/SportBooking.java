//package com.mysport.entities;
//
//import java.time.LocalDateTime;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.EnumType;
//import javax.persistence.Enumerated;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
//import javax.persistence.OneToOne;
//import javax.persistence.Table;
//
//import org.springframework.format.annotation.DateTimeFormat;
//
//import lombok.Getter;
//import lombok.Setter;
//
//@Entity
//@Table(name = "appointments")
//@Getter
//@Setter
//public class SportBooking {
//
//	@Column(name = "start")
//    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
//    private LocalDateTime start;
//
//    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
//    @Column(name = "end")
//    private LocalDateTime end;
//
//    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
//    @Column(name = "canceled_at")
//    private LocalDateTime canceledAt;
//
//    @OneToOne
//    @JoinColumn(name = "id_canceler")
//    private User canceler;
//
//    @Enumerated(EnumType.STRING)
//    @Column(name = "status")
//    private SportBookingStatus status;
//
//    @ManyToOne
//    @JoinColumn(name = "id_user")
//    private User user;
//
//
//    public SportBooking() {
//    }
//
//    public SportBooking(LocalDateTime start, LocalDateTime end, User user) {
//        this.start = start;
//        this.end = end;
//        this.user = user;
//    }
//
//}
