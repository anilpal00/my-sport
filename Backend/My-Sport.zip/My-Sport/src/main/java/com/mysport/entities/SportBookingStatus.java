//package com.mysport.entities;
//
//public enum SportBookingStatus {
//
//    SCHEDULED,
//    CANCELED
//}
