//package com.mysport.service;
//
//import java.time.LocalDateTime;
//
//public interface SportBookingService {
//
//	void bookSportGround(int workId, Long userId, LocalDateTime start);
//}
