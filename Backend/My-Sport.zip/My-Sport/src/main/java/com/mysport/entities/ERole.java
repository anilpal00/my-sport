package com.mysport.entities;

public enum ERole {
	ROLE_PLAYER,
    ROLE_ADMIN
}
