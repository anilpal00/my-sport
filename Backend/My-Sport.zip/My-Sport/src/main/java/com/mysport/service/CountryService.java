package com.mysport.service;

import java.util.List;

import com.mysport.entities.Country;


public interface CountryService {
	
	List<Country> getCountries();

}
