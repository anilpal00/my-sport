//package com.mysport.service.impl;
//
//import java.time.LocalDateTime;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.mysport.repository.UserRepository;
//import com.mysport.service.SportBookingService;
//
//@Service
//public class SportBookingServiceImpl implements SportBookingService {
//
//	
//	@Autowired
//	private UserRepository userRepo;
//	
////    @Override
////    public boolean isAvailable(int workId, int providerId, int customerId, LocalDateTime start) {
////        if (!workService.isWorkForCustomer(workId, customerId)) {
////            return false;
////        }
////        Work work = workService.getWorkById(workId);
////        TimePeroid timePeroid = new TimePeroid(start.toLocalTime(), start.toLocalTime().plusMinutes(work.getDuration()));
////        return getAvailableHours(providerId, customerId, workId, start.toLocalDate()).contains(timePeroid);
////    }
//    
//	@Override
//	public void createNewAppointment(int workId, Long userId, LocalDateTime start) {
//
////            Appointment appointment = new Appointment();
////            appointment.setStatus(AppointmentStatus.SCHEDULED);
////            appointment.setUser(userRepo.getById(userId));
////            Work work = workService.getWorkById(workId);
////            appointment.setWork(work);
////            appointment.setStart(start);
////            appointment.setEnd(start.plusMinutes(work.getDuration()));
////            appointmentRepository.save(appointment);
////            notificationService.newNewAppointmentScheduledNotification(appointment, true);
//
//		
//	}
//
//}
