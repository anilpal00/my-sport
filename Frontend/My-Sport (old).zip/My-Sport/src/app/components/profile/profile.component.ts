import { Component, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { TokenStorageService } from 'src/app/services/token-storage.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

export class ProfileComponent implements OnInit {
  submitted = false;
  currentUser: any;
  countries: any;
  msid: any;
  states: any;
  selectedCountry: any;
  selectedState: any;

  form: any = {
    firstName: '',
    lastName: '',
    mobileNo: '',
    dateOfBirth: '',
    pan: '',
    country: '',
    street: '',
    city: '',
    state: '',
  };

  isSuccessful = false;
  isSignUpFailed = false;
  errorMessage = '';
 

  constructor(private token: TokenStorageService, private authService: AuthService, private userService: UserService) { }

  ngOnInit(): void {
    this.currentUser = this.token.getUser();
    this.msid = this.token.getMsid();
    this.userService.getCountries().subscribe(
      data => {
        console.log("Retrieved countries: " + JSON.stringify(data));
        this.countries = data;
      }
    );
    this.onChange(event);
  }

  onSubmit(): void {
    const { firstName, lastName, mobileNo, dateOfBirth, pan, country, street, city, state } = this.form;


    this.userService.profileRegister(firstName, lastName, mobileNo, dateOfBirth, pan, this.selectedCountry, street, city, this.selectedState).subscribe(
      data => {
        console.log(data);
        this.submitted = true;
        this.isSuccessful = true;
        this.isSignUpFailed = false;
      },
      err => {
        this.errorMessage = err.error.message;
        this.isSignUpFailed = true;
        console.log(err);
      }
    );
  }

  changeState(event: any){
    this.selectedState = event.target.value;
  }

  onChange(event: any) {
    this.selectedCountry = event.target.value;

    if (event.target.value == "Brazil" && event.target.value != null) {
      this.userService.getStates("BR").subscribe(
        data => {
          console.log("Retrieved `countries`: " + JSON.stringify(data));
          this.states = data;
        }
      )
    }
    if (event.target.value == "Canada" && event.target.value != null) {
      this.userService.getStates("CA").subscribe(
        data => {
          console.log("Retrieved `countries`: " + JSON.stringify(data));
          this.states = data;
        }
      )
    }
    if (event.target.value == "Germany" && event.target.value != null) {
      this.userService.getStates("DE").subscribe(
        data => {
          console.log("Retrieved `countries`: " + JSON.stringify(data));
          this.states = data;
        }
      )
    }
    if (event.target.value == "India" && event.target.value != null) {
      this.userService.getStates("IN").subscribe(
        data => {
          console.log("Retrieved `countries`: " + JSON.stringify(data));
          this.states = data;
        }
      )
    }
    if (event.target.value == "Turkey" && event.target.value != null) {
      this.userService.getStates("TR").subscribe(
        data => {
          console.log("Retrieved `countries`: " + JSON.stringify(data));
          this.states = data;
        }
      )
    }
    if (event.target.value == "United States" && event.target.value != null) {
      this.userService.getStates("US").subscribe(
        data => {
          console.log("Retrieved `countries`: " + JSON.stringify(data));
          this.states = data;
        }
      )
    }
  }

  mobkeyPress(event: KeyboardEvent) {
    console.log(event);
    const pattern = /[0-9]/;
    const inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
        // invalid character, prevent input
        event.preventDefault();
    }
  }
}

