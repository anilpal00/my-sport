import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';

// const API_URL = 'http://localhost:8084/api/auth/';
const bOOKFACILITY_API = 'http://localhost:8084/api/book-sport-ground/';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ModalService {

  constructor(private http: HttpClient, private authService: AuthService) { }

  bookfacility( newData: { start: any; end: any; sportName: any; id_sport:any; status:number } ): Observable<any> {
    const user = AuthService.TokenStorage.getUser();
    return this.http.post
    (bOOKFACILITY_API + user.id, {
      start:newData.start,
      end:newData.end,
      sportName:newData.sportName,
      id_sport:newData.id_sport,
      status:newData.status
    },httpOptions);
  }
}
