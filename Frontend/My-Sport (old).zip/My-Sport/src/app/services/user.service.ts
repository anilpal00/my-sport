import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { Country } from '../common/country';

const API_URL = 'http://localhost:8084/api/auth/';
const PROFILE_API = 'http://localhost:8084/api/userprofile/';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient, private authService: AuthService) { }

  getPublicContent(): Observable<any> {
    return this.http.get(API_URL + 'all', { responseType: 'text' });
  }

  // getUserBoard(): Observable<any> {
  //   return this.http.get(API_URL + 'user', { responseType: 'text' });
  // }

  // getModeratorBoard(): Observable<any> {
  //   return this.http.get(API_URL + 'mod', { responseType: 'text' });
  // }

  // getAdminBoard(): Observable<any> {
  //   return this.http.get(API_URL + 'admin', { responseType: 'text' });
  // }

  profileRegister( firstName: String, lastName:String, mobileNo:String, dateOfBirth: Date, pan:Text, country:String, street:String, city:String, state:String ): Observable<any> {
    const user = AuthService.TokenStorage.getUser();
    return this.http.patch(PROFILE_API + user.id, {
      firstName,
      lastName,
      mobileNo, 
      dateOfBirth, 
      pan,
      country, 
      street, 
      city, 
      state
    },httpOptions);
  }

  getCountries(): Observable<any> {
    return this.http.get(PROFILE_API + 'countries');  
  }

  getStates(theCountryCode: string): Observable<any> {
    return this.http.get(PROFILE_API + 'state/'+theCountryCode);  
  }
}
