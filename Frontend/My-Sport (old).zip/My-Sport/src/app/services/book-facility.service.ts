import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TokenStorageService } from './token-storage.service';

const bOOKFACILITY_API = 'http://localhost:8084/api/book-sport-ground/';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class BookFacilityService {

  static TokenStorage = new TokenStorageService();
  
  constructor(private httpClient: HttpClient) { }

  getBookingData(): Observable<any> {
    // const user = BookFacilityService.TokenStorage.getUser();
    return this.httpClient.get<any>(bOOKFACILITY_API+ 'allBookingData');
  }
}
