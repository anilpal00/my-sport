import { Injectable } from '@angular/core';
import {
    CanActivate, Router,
    ActivatedRouteSnapshot,
    RouterStateSnapshot
} from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable()
export class AuthGuard implements CanActivate {

    isLoggedIn: boolean = false;
    public redirectUrl!: string;

    constructor(private authService: AuthService, private router: Router) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        // let url: string = state.url;

        // return this.checkLogin(url);

        if (localStorage.getItem('currentUser')) {
            // logged in so return true
            return true;
        }

        // not logged in so redirect to login page with the return url and return false
        this.router.navigate(['login'], { queryParams: { returnUrl: state.url }});
        return false;
    }

    // checkLogin(url: string): boolean {
    //     if (this.authService.isLoggedIn) { return true; }

    //     // Store the attempted URL for redirecting
    //     this.authService.redirectUrl = 'http://localhost:8084/api/auth/222';

    //     // Navigate to the login page with extras
    //     this.router.navigate(['/']);
    //     return false;
    // }
}