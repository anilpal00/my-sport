import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgxSmartModalService } from 'ngx-smart-modal';
import { ModalService } from 'src/app/services/modal.service';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit {
  submitted = false;
  @ViewChild('myform') form!: NgForm;

  data = [{
    recipient : 'Demo',
    message : 'Demo Message'
  }];
  
  editMode = false;
  editIndex!: string | number;
  
  isSuccessful = false;
  isSignUpFailed = false;
  errorMessage = '';
  
  constructor(public ngxSmartModalService: NgxSmartModalService, private modalService: ModalService) { }

  ngOnInit(): void {
  }

  //this.ngxSmartModalService.setModalData(obj, 'myModal');

  addData(form: { controls: any; }){
    var val = form.controls;
    const newData = {
      start: val.dateStart.value,
      end: val.dataEnd.value,
      sportName: val.sportName.value,
      id_sport:1,
      status:1
    };

    this.modalService.bookfacility(newData).subscribe(
      data=> {
        console.log(data);
        this.submitted = true;
        this.isSuccessful = true;
        this.isSignUpFailed = false;
      },
      err=>{
        this.errorMessage = err.error.message;
        this.isSignUpFailed = true;
        console.log(err);
      }
    )

    this.form.reset();
    this.ngxSmartModalService.close('myModal');
  }
 
  closeModal(id: any) {
    this.form.reset();
    this.editMode = false;
    this.ngxSmartModalService.close(id);
  }
}
