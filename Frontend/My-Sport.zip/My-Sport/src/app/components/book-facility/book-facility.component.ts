import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CalendarOptions } from '@fullcalendar/angular'; // useful for typechecking
import { BookFacilityService } from 'src/app/services/book-facility.service';


@Component({
  selector: 'app-book-facility',
  templateUrl: './book-facility.component.html',
  styleUrls: ['./book-facility.component.css']
})
export class BookFacilityComponent implements OnInit {
  // presentDays: number = 0;
  // absentDays: number = 0;
  bookingData:any = [];
  events:any;
  calendarOptions: CalendarOptions={};
  mappedItems:any;

  constructor(private http: HttpClient, private bookFacilityService: BookFacilityService){
    this.getBookingData();
  }

  ngOnInit(){
    // setTimeout(() => {
    //   this.calendarOptions = {
    //     initialView: 'dayGridMonth',
    //     dateClick:this.onDateClick.bind(this),
    //     events:this.Events
    //   }
    // },3500)
    //this.getBookingData();
  }

  // events:any = [
  //   { title: 'Football', start: '2022-11-01', end: '2022-11-01', color: '#0000FF' },
  //   { title: 'Cricket', start: '2022-11-02', end: '2022-11-01', color: '#0000FF' },
  //   { title: 'Football', start: '2022-11-03', end: '2022-11-01', color: '#FF0000' },
  // ];
  

  onDateClick(res:{dateStr:string}){
    alert("you clicked on :" + res.dateStr)
  }

  getBookingData() {
    this.bookFacilityService.getBookingData().subscribe(
      data => {
        //this.bookingData = data;
        this.events = data;
       
        // this.events.forEach(item: => {     
        //        if (!this.mappedItems[item.key]) {
        //          this.mappedItems[item.key] = [];
        //        }
              
        //        this.mappedItems[item.key].push({title : item.productId , start : item.price , end : item.discount, color : item.discount}));
        //    });
       // this.events = Object.keys(data).map((key) => [Number(key), data[key]]);
      //   this.events.forEach((item:any) => {     
      //     if (!this.mappedItems[item.key]) {
      //                 this.mappedItems[item.key] = [];
      //               }
      //       this.mappedItems[item.key].push({title : item.productId , start : item.price , end : item.discount, color : item.discount});
      // });
  this.calendarOptions = {
    initialView: 'dayGridMonth',
    dateClick:this.onDateClick.bind(this),
    events : this.events,
    eventClick:this.handleDateClick.bind(this),

  };
      },
      err=>{

      }
    )
  }

  handleDateClick(arg:any){
    console.log(arg);
    console.log(arg.event._def.title);
  }

}
