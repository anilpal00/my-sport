import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { ProfileComponent } from './components/profile/profile.component';
import { HomeComponent } from './components/home/home.component';

import { FullCalendarModule } from '@fullcalendar/angular'; // must go before plugins
import dayGridPlugin from '@fullcalendar/daygrid'; // a plugin!
import interactionPlugin from '@fullcalendar/interaction'; // a plugin!
import { NgxSmartModalModule,NgxSmartModalService } from 'ngx-smart-modal';

import { authInterceptorProviders } from './helpers/auth.interceptor';
import { BookFacilityComponent } from './components/book-facility/book-facility.component';
import { ModalComponent } from './components/modal/modal.component';

FullCalendarModule.registerPlugins([ // register FullCalendar plugins
  dayGridPlugin,
  interactionPlugin
]);

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ProfileComponent,
    HomeComponent,
    BookFacilityComponent,
    ModalComponent
  ],
  imports: [
    BrowserModule,
    FullCalendarModule, // register FullCalendar with you app
    AppRoutingModule,
    FormsModule,
    NgxSmartModalModule.forRoot(),
    HttpClientModule
  ],
  providers: [authInterceptorProviders, NgxSmartModalService],
  bootstrap: [AppComponent]
})


export class AppModule { }
